package bo;

public class ConvertedFileBO {

}
