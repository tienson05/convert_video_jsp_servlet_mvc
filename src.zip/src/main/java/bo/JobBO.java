package bo;

public class JobBO {

}
